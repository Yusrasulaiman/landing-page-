// Start Global Variables
const newNavBar = document.querySelector('.navbar__menu');
const newNavList = document.querySelector('#navbar__list');
const newSections = document.querySelectorAll('section');
const newFooter = document.querySelector('footer');
const newHeader = document.querySelector('.page__header');
// Get the initial offset position of the navigation bar
const navbarOffsetTop = newHeader.offsetTop;
// End Global Variables

// Start build the nav
function buildNewNav() {
  newSections.forEach((section) => {
    //Create the li elements that contained inside the ul
    const newNavButton = document.createElement('li');
    //Insert the html text to the li
    newNavButton.insertAdjacentHTML(
      'afterbegin',
      `<a href="#${section.id}" class="menu__link">${section.dataset.nav}</a>`
    );
    //Append the li to the ul
    newNavList.appendChild(newNavButton);

    //scrollBehavior Function Invoke
    scrollBehavior(newNavButton, section);
  });
  //Append the ul to the nav
  newNavBar.appendChild(newNavList);
}

//Build Nav Function Invoke
buildNewNav();
//End build the nav

// Start of Scroll to anchor ID using scrollTO event
function scrollBehavior(newNavButton, section) {
  newNavButton.addEventListener('click', function (event) {
    event.preventDefault();
    window.scrollTo({
      top: section.offsetTop,
      behavior: 'smooth',
    });
  });
}
// End of Scroll to anchor ID using scrollTO event

// Start of Set the Section class 'active' when it near to the top of viewport
function setActiveSection() {
  // Select all anchor using "menu__link" class
  const newNavActive = document.querySelectorAll('.menu__link');
  newSections.forEach((section, i) => {
    //Get the boundingrect for each section
    const sectionBond = section.getBoundingClientRect();
    //Check if the section is in viewport or not
    if (sectionBond.top <= 380 && sectionBond.bottom >= 350) {
      //section in viewport according to top and bottom boundings
      //add 'your-active-class' class to the specific section
      section.classList.add('your-active-class');
      //add 'active_button' class to the specific nav button according to section ID
      newNavActive[i].classList.add('active_button');
      //Change the background color of the section to black
      section.style.backgroundColor = 'black';
    } else {
      //Remove both section and navButton active classes when section is off sight
      section.classList.remove('your-active-class');
      newNavActive[i].classList.remove('active_button');
      //Reset the background color of the section
      section.style.backgroundColor = '';
    }
  });
}

// Function to highlight the active section in the navigation bar
function highlightActiveSection() {
  const newNavActive = document.querySelectorAll('.menu__link');
  newNavActive.forEach((navLink) => {
    navLink.classList.remove('active');
  });

  newSections.forEach((section) => {
    const sectionBond = section.getBoundingClientRect();

    if (sectionBond.top <= 380 && sectionBond.bottom >= 350) {
      const navLink = document.querySelector(`a[href="#${section.id}"]`);
      navLink.classList.add('active');
    }
  });
}

// End of Set the Section class 'active' when it near to the top of viewport

// Start of Toggle the NavBar According to User Scroll Activity
function toggleNavBar() {
  // Check the scroll position
  if (window.pageYOffset >= navbarOffsetTop) {
    // Add the "fixed" class to the navigation bar
    newHeader.classList.add('fixed');
  } else {
    // Remove the "fixed" class from the navigation bar
    newHeader.classList.remove('fixed');
  }
}

// End of Toggle the NavBar According to User Scroll Activity

// Start of the Scroll Event to execute the functions of setActiveSection and toggleNavBar
window.addEventListener('scroll', (event) => {
  setActiveSection();
  toggleNavBar();
  highlightActiveSection();
});
// End of the Scroll Event to execute the functions of setActiveSection and toggleNavBar

// Start of Go Up Button
//Create the div element for the button
const newGoUpButton = newFooter.insertAdjacentHTML(
  'beforebegin',
  `<div Id="return_top" ></div>`
);
// Scroll to top of the Landing Page using scrollTO event
document.getElementById('return_top').addEventListener('click', function () {
  window.scrollTo({
    top: 1,
    behavior: 'smooth',
  });
});
// End of Go Up Button